﻿/// <autosync enabled="true" />
/// <reference path="jquery-ui-1.11.1.js" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery-2.1.1.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.min.js" />
/// <reference path="jquery-ui.min-1.11.1.js" />
