﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Web;

namespace Magic.BusinessApps.Services.App_Code
{
    public class App
    {
        //This is the key, any class that implements this method that lives in the App_Code folder will start on app start
        public static void AppInitialize()
        {

        }


    }
}