﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace CODECorp.WcfIdentity.DataContract
{
    [DataContract]
    public abstract class BaseRequest
    {
        public BaseRequest()
        {

        }
    }
}
