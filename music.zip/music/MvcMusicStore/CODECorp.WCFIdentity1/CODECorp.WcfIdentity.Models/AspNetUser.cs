﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CODECorp.WcfIdentity.Models
{
    public partial class AspNetUser : Microsoft.AspNet.Identity.IUser
    {
    }
}
